
public class HEllo {
	public static void main(String... str) {
		System.out.print("hello word");
	}
}
